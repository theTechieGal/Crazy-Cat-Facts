/* eslint-disable */
import React, { useState } from "react";
import "./styles.css";
import { useQuery } from "react-query";
import axios from "axios";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

interface Fact {
  _id: string;
  text: string;
  type: string;
  user: any;
  upvotes: number;
}

interface ApiResponse {
  all: Fact[];
}

function getCatFacts() {
  var req = axios.get<ApiResponse>("https://cat-fact.herokuapp.com/facts");

  return req.then(res => res.data);
}

export default function App(this: any) {
  const [cnt, setCount] = useState(0);
  // cnt gives the number of clicks on Randomize button
  var { data, status } = useQuery("cat-facts", () => getCatFacts());

  if (status == "loading" || !data) {
    return "Loading...";
  }
  console.log(cnt);
  var count = 0;
  var index = 0;
  var current: any = null;
  do {
    current = data.all[index];
    if (current) {
      count++;
    }
    index++;
  } while (current);

  var numArr: number[] = [];

  numArr.length = 0;
  while (numArr.length < 3) {
    var temp = Math.floor(Math.random() * count);
    // Generating random number between 0 (included) and count (excluded)
    if (numArr.indexOf(temp) == -1) {
      // If not found in array(to generate distinct numbers)
      numArr.push(temp);
    }
  }
  var fact1Text, fact2Text, fact3Text;
  try {
    fact1Text = data.all[numArr[0]].text;
    console.log(fact1Text);
    var fact1UserFirstName = data.all[numArr[0]].user.name.first;
    var fact1UserLastName = data.all[numArr[0]].user.name.lsat;

    fact2Text = data.all[numArr[1]].text;
    console.log(fact2Text);

    var fact2UserFirstName = data.all[numArr[1]].user.name.first;
    var fact2UserLastName = data.all[numArr[1]].user.name.lsat;

    fact3Text = data.all[numArr[2]].text;
    console.log(fact3Text);

    var fact3UserFirstName = data.all[numArr[2]].user.name.first;
    var fact3UserLastName = data.all[numArr[2]].user.name.lsat;
  } catch (error) {
    console.log("Exception occured.");
  }
  return (
    <div className="App">
      <div className="title">
        3 Random cat facts
        <span>&nbsp;</span>
        <img className="photo" src={require("/images/paw.PNG")} />
      </div>
      <div className="totalfacts">Total facts: {count}</div>
      <p>
        <Button onClick={() => setCount(cnt + 1)} variant="info">
          Randomize
        </Button>
      </p>

      <div className="Fact">
        <Card border="light">
          <Card.Body>
            <Card.Text>
              <div>
                <img className="photo" src={require("/images/creator.PNG")} />
                <span>&nbsp;&nbsp;</span>
                Creator:{" "}
                <p className="cardtext">
                  {fact1UserFirstName} {fact1UserLastName}
                </p>
              </div>
            </Card.Text>
            <Card.Text>
              <div>
                <img className="photo" src={require("/images/fact.PNG")} />
                <span>&nbsp;&nbsp;</span>
                Fact: <p className="cardtext">{fact1Text}</p>
              </div>
            </Card.Text>
          </Card.Body>
        </Card>
      </div>

      <div className="Fact">
        <Card border="light">
          <Card.Body>
            <Card.Text>
              <div>
                <img className="photo" src={require("/images/creator.PNG")} />
                <span>&nbsp;&nbsp;</span>
                Creator:{" "}
                <p className="cardtext">
                  {fact2UserFirstName} {fact2UserLastName}
                </p>
              </div>
            </Card.Text>
            <Card.Text>
              <div>
                <img className="photo" src={require("/images/fact.PNG")} />
                <span>&nbsp;&nbsp;</span>
                Fact: <p className="cardtext">{fact2Text}</p>
              </div>
            </Card.Text>
          </Card.Body>
        </Card>
      </div>

      <div className="Fact">
        <Card border="light">
          <Card.Body>
            <Card.Text>
              <div>
                <img className="photo" src={require("/images/creator.PNG")} />
                <span>&nbsp;&nbsp;</span>
                Creator:{" "}
                <p className="cardtext">
                  {fact3UserFirstName} {fact3UserLastName}
                </p>
              </div>
            </Card.Text>
            <Card.Text>
              <div>
                <img className="photo" src={require("/images/fact.PNG")} />
                <span>&nbsp;&nbsp;</span>
                Fact: <p className="cardtext">{fact3Text}</p>
              </div>
            </Card.Text>
          </Card.Body>
        </Card>
      </div>
      <div className="clicks">
        <Card border="info">
          <Card.Body>
            <Card.Text>
              <div>
                <img
                  className="photosuccess"
                  src={require("/images/success.PNG")}
                />
                <span>&nbsp;</span>
                Success! You have clicked {cnt} times.
              </div>
            </Card.Text>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}
